package fr.epita.datamodels;

public class Student {

    private String name;
    private String id;

}
